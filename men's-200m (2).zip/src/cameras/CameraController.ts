import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CameraPresetId, STADIUM_CONFIG } from '../config';

export class CameraController {
  public readonly camera: THREE.PerspectiveCamera;
  public readonly controls: OrbitControls;

  private currentPreset: CameraPresetId = 'exterior';
  private autoOrbit = false;
  private transitioning = false;
  private transitionProgress = 0;
  private transitionDuration = 1.05;

  private fromPos = new THREE.Vector3();
  private fromTarget = new THREE.Vector3();
  private fromFov = 44;

  private toPos = new THREE.Vector3();
  private toTarget = new THREE.Vector3();
  private toFov = 44;

  private onUserInteract: () => void;

  constructor(
    domElement: HTMLElement,
    aspect: number,
    isSoftwareGl: boolean
  ) {
    const initial = STADIUM_CONFIG.cameras.exterior;
    this.camera = new THREE.PerspectiveCamera(initial.fov, aspect, 0.4, 2200);
    this.camera.position.set(...initial.pos);

    this.controls = new OrbitControls(this.camera, domElement);
    this.controls.target.set(...initial.target);
    this.controls.enableDamping = !isSoftwareGl;
    this.controls.dampingFactor = 0.065;
    this.controls.rotateSpeed = 0.72;
    this.controls.zoomSpeed = 0.85;
    this.controls.panSpeed = 0.75;
    this.controls.minDistance = 8;
    this.controls.maxDistance = 360;
    // Prevent camera from ever dipping below the stadium ground plane
    this.controls.maxPolarAngle = Math.PI * 0.485;
    this.controls.minPolarAngle = 0.04;
    this.controls.autoRotateSpeed = 0.48;
    this.controls.touches = {
      ONE: THREE.TOUCH.ROTATE,
      TWO: THREE.TOUCH.DOLLY_PAN,
    };
    this.controls.update();

    this.onUserInteract = () => {
      if (this.transitioning) {
        this.transitioning = false;
      }
    };
    this.controls.addEventListener('start', this.onUserInteract);
  }

  public getPreset(): CameraPresetId {
    return this.currentPreset;
  }

  public isAutoOrbit(): boolean {
    return this.autoOrbit;
  }

  public setAutoOrbit(enabled: boolean): void {
    this.autoOrbit = enabled;
    this.controls.autoRotate = enabled;
  }

  public goTo(preset: CameraPresetId, immediate = false): void {
    const cfg = STADIUM_CONFIG.cameras[preset];
    if (!cfg) return;
    this.currentPreset = preset;

    if (immediate) {
      this.transitioning = false;
      this.camera.position.set(...cfg.pos);
      this.controls.target.set(...cfg.target);
      this.camera.fov = cfg.fov;
      this.camera.updateProjectionMatrix();
      this.controls.update();
      return;
    }

    this.fromPos.copy(this.camera.position);
    this.fromTarget.copy(this.controls.target);
    this.fromFov = this.camera.fov;

    this.toPos.set(...cfg.pos);
    this.toTarget.set(...cfg.target);
    this.toFov = cfg.fov;

    this.transitionProgress = 0;
    this.transitioning = true;
  }

  public resize(width: number, height: number): void {
    this.camera.aspect = Math.max(0.1, width / Math.max(1, height));
    this.camera.updateProjectionMatrix();
  }

  public update(dt: number): void {
    if (this.transitioning) {
      this.transitionProgress = Math.min(1, this.transitionProgress + dt / this.transitionDuration);
      // Cubic ease-out
      const t = 1 - Math.pow(1 - this.transitionProgress, 3);
      this.camera.position.lerpVectors(this.fromPos, this.toPos, t);
      this.controls.target.lerpVectors(this.fromTarget, this.toTarget, t);
      this.camera.fov = this.fromFov + (this.toFov - this.fromFov) * t;
      this.camera.updateProjectionMatrix();
      if (this.transitionProgress >= 1) {
        this.transitioning = false;
      }
    }

    this.controls.update();
    // Clamp camera height cleanly above terrain
    if (this.camera.position.y < 1.0) {
      this.camera.position.y = 1.0;
    }
  }

  public dispose(): void {
    this.controls.removeEventListener('start', this.onUserInteract);
    this.controls.dispose();
  }
}
