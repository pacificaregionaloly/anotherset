# Men's 200 Metres — Wavesports AI Event Module

Self-contained Men's 200 Metres race module inside `event/men200m/` for the **1st Pacifica Regional Olympics 2026** at **Klemonserrat Stadium**, broadcast by **Wavesports Television (WSTV)**.

---

## Opening the Men's 200m Page

- Dev server URL: `/` or `/men200m.html` (e.g. `http://localhost:3000/` or `http://localhost:3000/men200m.html`)
- Dev-only mock mode: `/?mock=1` or `/men200m.html?mock=1` (with optional `&seed=123456`, `&clean=1`, `&mode=admin`, `&race=men-200m-final-1`)
- Production builds output `dist/index.html` and `dist/men200m.html`, both loading the Men's 200m event with zero cross-event imports or shared `event/shared/` code.

---

## Stadium Integrity Statement

No stadium file (`src/*`) or stadium 3D object (track, bowl, roof, boards, branding, crowd, officials, orbit camera, HUD, 30 FPS loop) was modified. All Men's 200m additions (staggered start lines, tangent-aligned lane numbers, angled starting blocks, starter stand, gun flash/smoke, wind gauge, wind flags, recall cones, finish laser) live additively inside one `THREE.Group` named `EventLayer_Men200m`.

Stadium public API calls used (`window.WSTV.stadium`):
- `stadium.scene` (additive `EventLayer_Men200m` group attach/detach)
- `stadium.camera` & `stadium.renderer` (broadcast director + optional West Board top-down oval `WebGLRenderTarget`)
- `stadium.getTrackPath(lane).pointAt(distanceMeters)` (derives the 0.20 m inside-line running path & stagger geometry without altering stadium paths)
- `stadium.addUpdateCallback(fn)` (30 Hz fixed-timestep simulation + render interpolation)
- `stadium.boards.get(name)` / `writeMessage(...)` / `setSource(...)`
- `stadium.people.spawnPerson(...)` / `removePerson(...)` / `setPose(...)` / `getAll()`
- `stadium.cameras.goTo(preset)`

### Stadium API Gaps Worked Around in `event/men200m/`
- **0.20 m Running Line & Staggered 200m Geometry:** `stadium.getTrackPath(lane)` returns points along the lane center line (`0.61 m` from inside lane line). `TrackExtension200m.ts` derives an inward `0.41 m` offset to the official `0.20 m` running line (`0.20 m` from the curb in Lane 1) and maps `raceDistanceMeters` smoothly from 200.00 m back from the finish line (including the `0.3135 m` pre-bend entry in Lane 1 and angled blocks/lines along the West Bend tangent for Lanes 1–8).
- **Custom Sprint, Curve-Lean & Incident Animations:** `StadiumAPI` only provides idle/jog poses (`idle`, `walk`, `jog`, `sit`, `wave`, `clap`, `cheer`). `AthleteAnimator200m.ts` animates `PersonInstance` limb pivots inside `addUpdateCallback` for call-room walkout, shakeout skips, `on_your_marks`, `set_crouch`, `false_start_twitch`, `sprint` with centripetal inward curve lean (`bodyPivot.rotation.z = -leanRad`), `stumble`, `fall_slide`, `pull_up_injured`, `limp`, `lean_finish`, `celebrate`, and `disappointed`.
- **Board `setText` / `addText` / `clearText` & Live Top-Down Mini-View:** `BoardController200m.ts` wraps `stadium.boards.get(name)` / `writeMessage` / `setSource` and uses a dedicated overhead `PerspectiveCamera` + `WebGLRenderTarget` on `westBoard` to render the whole 400 m oval simultaneously.

---

## Staggered Start Self-Check

At startup, `EventTrackLayer200m` integrates a 1,000-segment polyline along each lane's derived 0.20 m running line from `d = 0.00 m` (staggered start) to `d = 200.00 m` (finish line):
- Home straight = `84.39 m`; bend portion = `115.61 m`
- Expected stagger between neighbouring lanes: `π × 1.22 ≈ 3.83 m` (Lane 8 starts `~26.83 m` ahead of Lane 1)
- All 8 lanes must measure `200.00 m ± 0.01 m`; otherwise the race is blocked and `SELF_CHECK_FAILED` is reported.

---

## Configuration (`event/men200m/config/index.ts`)

| Setting | Default | Override |
|---|---|---|
| `API_BASE_URL` | `/api/wavesports` | `VITE_WAVESPORTS_API_BASE_URL` or `?apiBase=...` |
| `API_TOKEN` | `""` | `VITE_WAVESPORTS_API_TOKEN` |
| `RACE_ID` | `men-200m-final-1` | `VITE_WAVESPORTS_200M_RACE_ID` or `?race=...` |
| `POLL_INTERVAL_MS` | `2500` | `VITE_WAVESPORTS_POLL_MS` |
| `MOCK_API` | `false` | `?mock=1` or `MOCK_API = true` (dev builds only) |

---

## Wavesports API & Incidents

See `docs/men200m-api-contract.md` for full HTTP/SSE/WebSocket schemas (`event: "men_200m"`, setup validation, `start`/`abort`/`reset` commands, status updates, and results payload with `50`/`100`/`150` splits, `bendTime`, and `straightTime`).

Default rare incident probabilities live in `event/men200m/config/incidents.ts` (`falseStartBaseRate: 0.028`, `stumbledStartRate: 0.032`, `fallOrTripRate: 0.015`, `injuryPullUpRate: 0.010`, `laneViolationRate: 0.015`, `collisionBrushRate: 0.006`, `lateDnsRate: 0.005`, `equipmentBlockSlipRate: 0.007`, `breakoutPerformanceRate: 0.045`, `maxRecalls: 3`) and can be overridden (or zeroed) via `setup.incidentOverrides`.
