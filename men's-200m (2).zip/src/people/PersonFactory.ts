import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { drawRampantLion } from '../branding/textures';
import { STADIUM_CONFIG } from '../config';

export type PersonType =
  | 'runner'
  | 'official'
  | 'media'
  | 'volunteer'
  | 'medical'
  | 'commentator';

export type PersonGender = 'men' | 'women';

export type PersonPoseName =
  | 'idle'
  | 'stretch'
  | 'warmup'
  | 'jog'
  | 'seated'
  | 'camera';

export interface PersonOptions {
  id?: string;
  gender?: PersonGender;
  kitPrimary?: string;
  kitSecondary?: string;
  skinTone?: string;
  number?: string;
  name?: string;
  showLabel?: boolean;
  pose?: PersonPoseName;
  position?: [number, number, number];
  heading?: number;
  hasCamera?: boolean;
  hasMedicalBag?: boolean;
  /** For runners gently jogging along a track lane */
  jogLane?: number;
  jogOffsetMeters?: number;
  jogSpeedMps?: number;
}

export interface PersonInstance {
  id: string;
  type: PersonType;
  pose: PersonPoseName;
  options: PersonOptions;
  root: THREE.Group;
  bodyPivot: THREE.Group;
  torso: THREE.Group;
  leftShoulder: THREE.Group;
  rightShoulder: THREE.Group;
  leftElbow: THREE.Group;
  rightElbow: THREE.Group;
  leftHip: THREE.Group;
  rightHip: THREE.Group;
  leftKnee: THREE.Group;
  rightKnee: THREE.Group;
  labelSprite: THREE.Sprite | null;
  phase: number;
  jogDistance: number;
  dispose: () => void;
}

/**
 * Swappable Custom GLB Athlete Loader:
 * Call this or set `STADIUM_CONFIG.brandingSlots.customAthleteGlbUrl` to replace the procedural placeholder.
 */
export async function loadCustomAthleteModel(url: string): Promise<THREE.Group> {
  const loader = new GLTFLoader();
  const gltf = await loader.loadAsync(url);
  gltf.scene.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      child.castShadow = true;
      child.receiveShadow = true;
    }
  });
  return gltf.scene;
}

function createKitTexture(
  type: PersonType,
  primary: string,
  secondary: string,
  bib?: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = primary;
  ctx.fillRect(0, 0, 256, 256);

  ctx.fillStyle = secondary;
  ctx.fillRect(0, 0, 256, 34);
  ctx.fillRect(16, 0, 20, 256);
  ctx.fillRect(220, 0, 20, 256);

  ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
  ctx.fillRect(0, 34, 256, 8);

  if (type === 'runner') {
    drawRampantLion(ctx, 128, 86, 0.42, '#0A0D14');
  }

  if (bib) {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(72, 128, 112, 62);
    ctx.strokeStyle = '#0F172A';
    ctx.lineWidth = 4;
    ctx.strokeRect(72, 128, 112, 62);
    ctx.fillStyle = '#0F172A';
    ctx.font = 'bold 38px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(bib, 128, 159);
  } else if (type === 'medical') {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(114, 120, 28, 76);
    ctx.fillRect(90, 144, 76, 28);
  } else if (type === 'media') {
    ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
    ctx.font = 'bold 34px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('WSTV', 128, 160);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createNameLabel(name: string, number?: string): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 280;
  canvas.height = 68;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = 'rgba(4, 15, 38, 0.84)';
  ctx.beginPath();
  ctx.roundRect(4, 4, 272, 60, 10);
  ctx.fill();
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.75)';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = '#F8FAFC';
  ctx.font = '600 22px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const label = number ? `#${number} ${name}` : name;
  ctx.fillText(label.slice(0, 20), 140, 35);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false })
  );
  sprite.scale.set(1.9, 0.46, 1);
  sprite.position.set(0, 2.25, 0);
  return sprite;
}

let personCounter = 0;

/**
 * Shared Person Factory creating composite low-poly humanoids (runners, officials, media, staff).
 * Grounded bottom-center pivot at y = 0, facing +Z in local space.
 */
export function createPerson(type: PersonType, options: PersonOptions = {}): PersonInstance {
  personCounter++;
  const id = options.id ?? `${type}-${personCounter}`;
  const gender = options.gender ?? 'men';
  const isFemale = gender === 'women';

  const defaultColors: Record<PersonType, [string, string]> = {
    runner: ['#0033A0', '#F8FAFC'],
    official: ['#0033A0', '#D4AF37'],
    media: ['#0F172A', '#38BDF8'],
    volunteer: ['#1D5FD6', '#F8FAFC'],
    medical: ['#DC2626', '#FFFFFF'],
    commentator: ['#041436', '#D4AF37'],
  };

  const primary = options.kitPrimary ?? defaultColors[type][0];
  const secondary = options.kitSecondary ?? defaultColors[type][1];
  const skinTone = options.skinTone ?? '#C68642';

  const root = new THREE.Group();
  root.name = `Person_${id}`;
  const bodyPivot = new THREE.Group();
  bodyPivot.scale.setScalar(isFemale ? 0.94 : 1.0);
  root.add(bodyPivot);

  const shoulderW = isFemale ? 0.175 : 0.215;
  const chestW = isFemale ? 0.30 : 0.35;
  const hipW = isFemale ? 0.11 : 0.10;

  const skinMat = new THREE.MeshStandardMaterial({ color: skinTone, roughness: 0.7 });
  const kitTex = createKitTexture(type, primary, secondary, options.number);
  const torsoMat = new THREE.MeshStandardMaterial({ map: kitTex, roughness: 0.72 });
  const pantsMat = new THREE.MeshStandardMaterial({
    color: type === 'runner' ? primary : '#0F172A',
    roughness: 0.8,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: type === 'runner' ? STADIUM_CONFIG.colors.goldBright : '#1E293B',
    roughness: 0.4,
  });
  const hairMat = new THREE.MeshStandardMaterial({ color: '#111827', roughness: 0.88 });

  const pelvis = new THREE.Mesh(new THREE.BoxGeometry(0.27, 0.18, 0.18), pantsMat);
  pelvis.position.set(0, 0.92, 0);
  pelvis.castShadow = true;
  bodyPivot.add(pelvis);

  const torso = new THREE.Group();
  torso.position.set(0, 0.98, 0);
  bodyPivot.add(torso);

  const chest = new THREE.Mesh(new THREE.BoxGeometry(chestW, 0.46, 0.21), torsoMat);
  chest.position.set(0, 0.24, 0);
  chest.castShadow = true;
  torso.add(chest);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.125, 10, 8), skinMat);
  head.position.set(0, 0.61, 0.01);
  head.castShadow = true;
  torso.add(head);

  const hair = new THREE.Mesh(
    new THREE.SphereGeometry(0.13, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.55),
    hairMat
  );
  hair.position.set(0, 0.625, -0.005);
  torso.add(hair);

  const makeArm = (side: -1 | 1) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * (shoulderW + 0.03), 0.42, 0);
    torso.add(shoulder);

    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.046, 0.21, 4, 6), skinMat);
    upper.position.set(0, -0.14, 0);
    upper.castShadow = true;
    shoulder.add(upper);

    const elbow = new THREE.Group();
    elbow.position.set(0, -0.27, 0);
    shoulder.add(elbow);

    const fore = new THREE.Mesh(new THREE.CapsuleGeometry(0.038, 0.2, 4, 6), skinMat);
    fore.position.set(0, -0.13, 0);
    fore.castShadow = true;
    elbow.add(fore);

    return { shoulder, elbow };
  };
  const leftArm = makeArm(-1);
  const rightArm = makeArm(1);

  const makeLeg = (side: -1 | 1) => {
    const hip = new THREE.Group();
    hip.position.set(side * hipW, 0.90, 0);
    bodyPivot.add(hip);

    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.33, 4, 6), pantsMat);
    thigh.position.set(0, -0.20, 0);
    thigh.castShadow = true;
    hip.add(thigh);

    const knee = new THREE.Group();
    knee.position.set(0, -0.43, 0);
    hip.add(knee);

    const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.048, 0.33, 4, 6), skinMat);
    shin.position.set(0, -0.20, 0);
    shin.castShadow = true;
    knee.add(shin);

    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.065, 0.21), shoeMat);
    shoe.position.set(0, -0.42, 0.04);
    knee.add(shoe);

    return { hip, knee };
  };
  const leftLeg = makeLeg(-1);
  const rightLeg = makeLeg(1);

  if (options.hasCamera) {
    const camBody = new THREE.Mesh(
      new THREE.BoxGeometry(0.22, 0.20, 0.42),
      new THREE.MeshStandardMaterial({ color: '#1E293B', metalness: 0.6, roughness: 0.3 })
    );
    camBody.position.set(0.12, 0.48, 0.28);
    torso.add(camBody);
  }

  let labelSprite: THREE.Sprite | null = null;
  if (options.name && options.showLabel !== false) {
    labelSprite = createNameLabel(options.name, options.number);
    root.add(labelSprite);
  }

  if (options.position) {
    root.position.set(options.position[0], options.position[1], options.position[2]);
  }
  if (options.heading !== undefined) {
    root.rotation.y = options.heading;
  }

  // Optional custom GLB athlete swap
  if (type === 'runner' && STADIUM_CONFIG.brandingSlots.customAthleteGlbUrl) {
    void loadCustomAthleteModel(STADIUM_CONFIG.brandingSlots.customAthleteGlbUrl)
      .then((custom) => {
        bodyPivot.visible = false;
        root.add(custom);
      })
      .catch(() => {});
  }

  const dispose = () => {
    root.traverse((o) => {
      if (o instanceof THREE.Mesh) o.geometry.dispose();
    });
    skinMat.dispose();
    torsoMat.dispose();
    pantsMat.dispose();
    shoeMat.dispose();
    hairMat.dispose();
    kitTex.dispose();
    if (labelSprite) {
      (labelSprite.material as THREE.SpriteMaterial).map?.dispose();
      labelSprite.material.dispose();
    }
  };

  return {
    id,
    type,
    pose: options.pose ?? 'idle',
    options,
    root,
    bodyPivot,
    torso,
    leftShoulder: leftArm.shoulder,
    rightShoulder: rightArm.shoulder,
    leftElbow: leftArm.elbow,
    rightElbow: rightArm.elbow,
    leftHip: leftLeg.hip,
    rightHip: rightLeg.hip,
    leftKnee: leftLeg.knee,
    rightKnee: rightLeg.knee,
    labelSprite,
    phase: (personCounter * 0.9) % (Math.PI * 2),
    jogDistance: options.jogOffsetMeters ?? 0,
    dispose,
  };
}

/**
 * Updates looping idle / stretch / warmup / gentle jog / seated / camera animations.
 * No racing animations.
 */
export function updatePersonPose(p: PersonInstance, elapsed: number, dt: number): void {
  const t = elapsed + p.phase;
  p.bodyPivot.position.y = 0;

  switch (p.pose) {
    case 'idle': {
      p.torso.rotation.set(0.02 + Math.sin(t * 1.4) * 0.02, Math.sin(t * 0.7) * 0.06, 0);
      p.leftShoulder.rotation.set(0, 0, -0.08);
      p.rightShoulder.rotation.set(0, 0, 0.08);
      p.leftElbow.rotation.x = -0.22;
      p.rightElbow.rotation.x = -0.22;
      p.leftHip.rotation.x = 0;
      p.rightHip.rotation.x = 0;
      p.leftKnee.rotation.x = 0;
      p.rightKnee.rotation.x = 0;
      break;
    }
    case 'stretch': {
      const s = (Math.sin(t * 1.8) + 1) * 0.5;
      p.torso.rotation.set(0.15 + s * 0.35, 0, 0);
      p.leftShoulder.rotation.set(-0.6 - s * 1.2, 0, -0.15);
      p.rightShoulder.rotation.set(-0.6 - s * 1.2, 0, 0.15);
      p.leftElbow.rotation.x = -0.3;
      p.rightElbow.rotation.x = -0.3;
      p.leftHip.rotation.x = -0.15 - s * 0.25;
      p.rightHip.rotation.x = 0.1;
      p.leftKnee.rotation.x = 0.2;
      p.rightKnee.rotation.x = 0.05;
      break;
    }
    case 'warmup': {
      // High-knee warm-up drills in place
      const cycle = t * 5.2;
      const liftL = Math.max(0, Math.sin(cycle));
      const liftR = Math.max(0, -Math.sin(cycle));
      p.bodyPivot.position.y = Math.abs(Math.cos(cycle)) * 0.04;
      p.torso.rotation.set(0.08, 0, 0);
      p.leftHip.rotation.x = -liftL * 0.95;
      p.rightHip.rotation.x = -liftR * 0.95;
      p.leftKnee.rotation.x = liftL * 1.25;
      p.rightKnee.rotation.x = liftR * 1.25;
      p.leftShoulder.rotation.set(Math.sin(cycle) * 0.6, 0, -0.1);
      p.rightShoulder.rotation.set(-Math.sin(cycle) * 0.6, 0, 0.1);
      p.leftElbow.rotation.x = -1.35;
      p.rightElbow.rotation.x = -1.35;
      break;
    }
    case 'jog': {
      // Gentle warm-up jog cadence (~3.2 m/s)
      const cycle = t * 6.8;
      const s = Math.sin(cycle);
      const c = Math.cos(cycle);
      p.bodyPivot.position.y = Math.abs(c) * 0.045;
      p.torso.rotation.set(0.12, s * 0.06, 0);
      p.leftHip.rotation.x = s * 0.55;
      p.rightHip.rotation.x = -s * 0.55;
      p.leftKnee.rotation.x = Math.max(0.1, -c * 0.75 + 0.45);
      p.rightKnee.rotation.x = Math.max(0.1, c * 0.75 + 0.45);
      p.leftShoulder.rotation.set(-s * 0.5, 0, -0.1);
      p.rightShoulder.rotation.set(s * 0.5, 0, 0.1);
      p.leftElbow.rotation.x = -1.25;
      p.rightElbow.rotation.x = -1.25;
      void dt;
      break;
    }
    case 'seated': {
      p.bodyPivot.position.y = -0.34;
      p.torso.rotation.set(0.05 + Math.sin(t * 1.2) * 0.03, Math.sin(t * 0.8) * 0.12, 0);
      p.leftHip.rotation.x = -1.45;
      p.rightHip.rotation.x = -1.45;
      p.leftKnee.rotation.x = 1.45;
      p.rightKnee.rotation.x = 1.45;
      p.leftShoulder.rotation.set(-0.5, 0, -0.1);
      p.rightShoulder.rotation.set(-0.5, 0, 0.1);
      p.leftElbow.rotation.x = -0.8;
      p.rightElbow.rotation.x = -0.8;
      break;
    }
    case 'camera': {
      p.torso.rotation.set(0.05, Math.sin(t * 0.55) * 0.25, 0);
      p.leftShoulder.rotation.set(-0.85, 0, -0.12);
      p.rightShoulder.rotation.set(-0.85, 0, 0.12);
      p.leftElbow.rotation.x = -1.1;
      p.rightElbow.rotation.x = -1.1;
      p.leftHip.rotation.x = 0;
      p.rightHip.rotation.x = 0;
      p.leftKnee.rotation.x = 0;
      p.rightKnee.rotation.x = 0;
      break;
    }
  }
}
