import * as THREE from 'three';
import {
  BoardMessagePayload,
  BoardName,
  BoardSourceKind,
  STADIUM_CONFIG,
} from '../config';

export interface PostMessagePayload {
  type?: string;
  board?: BoardName | 'all';
  title?: string;
  subtitle?: string;
  clock?: string;
  imageDataUrl?: string;
  rows?: Array<{ lane?: number; label: string; value: string; color?: string }>;
}

export interface BoardSourceOptions {
  /** For 'canvas2d': custom per-frame draw function */
  draw?: (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    elapsedSeconds: number
  ) => void;
  /** For 'video': HTMLVideoElement or video URL */
  video?: HTMLVideoElement;
  videoUrl?: string;
  /** For 'renderTarget': custom WebGLRenderTarget texture */
  renderTargetTexture?: THREE.Texture;
  /** For 'message': custom broadcast message payload */
  message?: BoardMessagePayload;
}

/**
 * Reusable live-updatable stadium LED screen supporting 5 runtime-switchable sources:
 * 'demo' | 'canvas2d' | 'video' | 'renderTarget' | 'postMessage'
 */
export class BoardScreen {
  public readonly name: BoardName;
  public readonly width: number;
  public readonly height: number;
  public readonly mesh: THREE.Mesh;
  public readonly material: THREE.MeshBasicMaterial;
  public readonly canvas: HTMLCanvasElement;
  public readonly ctx: CanvasRenderingContext2D;
  public readonly canvasTexture: THREE.CanvasTexture;

  private sourceKind: BoardSourceKind = 'demo';
  private customDraw?: BoardSourceOptions['draw'];
  private videoTexture: THREE.VideoTexture | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private syntheticVideoCanvas: HTMLCanvasElement | null = null;
  private renderTargetTex: THREE.Texture | null = null;
  private lastPostPayload: PostMessagePayload | null = null;
  private customMessage: BoardMessagePayload = {
    title: 'WELCOME TO KLEMONSERRAT STADIUM',
    body: '1st Pacifica Regional Olympics 2026 · Plead City, New Pleadland',
    ticker: 'WAVESPORTS TELEVISION (WSTV) LIVE VENUE FEED',
    theme: 'royal',
  };
  private postImage: HTMLImageElement | null = null;
  private lastRedrawMs = -1;
  private isRing: boolean;

  constructor(params: {
    name: BoardName;
    canvasWidth: number;
    canvasHeight: number;
    worldWidth: number;
    worldHeight: number;
    maxAnisotropy: number;
    isRing?: boolean;
    geometry?: THREE.BufferGeometry;
    repeatX?: number;
  }) {
    this.name = params.name;
    this.width = params.canvasWidth;
    this.height = params.canvasHeight;
    this.isRing = Boolean(params.isRing);

    this.canvas = document.createElement('canvas');
    this.canvas.width = params.canvasWidth;
    this.canvas.height = params.canvasHeight;
    this.ctx = this.canvas.getContext('2d')!;

    this.canvasTexture = new THREE.CanvasTexture(this.canvas);
    this.canvasTexture.colorSpace = THREE.SRGBColorSpace;
    this.canvasTexture.anisotropy = params.maxAnisotropy;
    if (params.repeatX && params.repeatX > 1) {
      this.canvasTexture.wrapS = THREE.RepeatWrapping;
      this.canvasTexture.repeat.set(params.repeatX, 1);
    }

    this.material = new THREE.MeshBasicMaterial({
      map: this.canvasTexture,
      side: this.isRing ? THREE.DoubleSide : THREE.FrontSide,
    });

    const geo =
      params.geometry ?? new THREE.PlaneGeometry(params.worldWidth, params.worldHeight);
    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.name = `BoardScreen_${params.name}`;

    // Draw initial frame immediately
    this.renderDemoFrame(0);
    this.canvasTexture.needsUpdate = true;
  }

  public getSource(): BoardSourceKind {
    return this.sourceKind;
  }

  public setSource(kind: BoardSourceKind, options: BoardSourceOptions = {}): void {
    this.sourceKind = kind;
    this.customDraw = options.draw;
    if (options.message) {
      this.customMessage = { ...options.message };
    }

    if (kind === 'renderTarget' && options.renderTargetTexture) {
      this.renderTargetTex = options.renderTargetTexture;
      this.material.map = this.renderTargetTex;
      this.material.needsUpdate = true;
      return;
    }

    if (kind === 'video') {
      this.setupVideoSource(options);
      if (this.videoTexture) {
        this.material.map = this.videoTexture;
        this.material.needsUpdate = true;
      }
      return;
    }

    if (kind === 'renderTarget' && this.renderTargetTex) {
      this.material.map = this.renderTargetTex;
      this.material.needsUpdate = true;
      return;
    }

    this.material.map = this.canvasTexture;
    this.material.needsUpdate = true;
    this.lastRedrawMs = -1;
  }

  public setMessage(payload: BoardMessagePayload): void {
    this.customMessage = {
      title: payload.title.trim() || 'KLEMONSERRAT STADIUM',
      body: payload.body?.trim() ?? '',
      ticker: payload.ticker?.trim(),
      theme: payload.theme ?? 'royal',
    };
    this.setSource('message');
  }

  public getMessage(): BoardMessagePayload {
    return { ...this.customMessage };
  }

  public bindSharedRenderTargetTexture(tex: THREE.Texture): void {
    this.renderTargetTex = tex;
    if (this.sourceKind === 'renderTarget') {
      this.material.map = tex;
      this.material.needsUpdate = true;
    }
  }

  public handlePostMessage(payload: PostMessagePayload): void {
    this.lastPostPayload = payload;
    if (payload.imageDataUrl) {
      const img = new Image();
      img.onload = () => {
        this.postImage = img;
        this.lastRedrawMs = -1;
      };
      img.src = payload.imageDataUrl;
    } else {
      this.lastRedrawMs = -1;
    }
  }

  private setupVideoSource(options: BoardSourceOptions): void {
    if (this.videoTexture) {
      this.videoTexture.dispose();
      this.videoTexture = null;
    }

    if (options.video) {
      this.videoElement = options.video;
    } else if (options.videoUrl) {
      const v = document.createElement('video');
      v.src = options.videoUrl;
      v.crossOrigin = 'anonymous';
      v.loop = true;
      v.muted = true;
      v.playsInline = true;
      void v.play().catch(() => {});
      this.videoElement = v;
    } else {
      // Built-in self-contained HTMLVideoElement fed by a live Canvas captureStream (no external URL)
      const vCanvas = document.createElement('canvas');
      vCanvas.width = 512;
      vCanvas.height = 256;
      this.syntheticVideoCanvas = vCanvas;
      const v = document.createElement('video');
      v.muted = true;
      v.playsInline = true;
      v.autoplay = true;
      if (typeof vCanvas.captureStream === 'function') {
        v.srcObject = vCanvas.captureStream(24);
        void v.play().catch(() => {});
      }
      this.videoElement = v;
    }

    if (this.videoElement) {
      this.videoTexture = new THREE.VideoTexture(this.videoElement);
      this.videoTexture.colorSpace = THREE.SRGBColorSpace;
      this.videoTexture.minFilter = THREE.LinearFilter;
      this.videoTexture.magFilter = THREE.LinearFilter;
    }
  }

  public update(elapsedSeconds: number, nowMs: number): void {
    if (this.sourceKind === 'renderTarget') {
      return; // GPU RenderTarget updates automatically via BoardManager
    }

    if (this.sourceKind === 'video') {
      if (this.syntheticVideoCanvas) {
        this.drawSyntheticVideoStreamFrame(elapsedSeconds);
      }
      if (this.videoTexture) {
        this.videoTexture.needsUpdate = true;
      }
      return;
    }

    // Throttle 2D canvas redraws gently to ~30 fps for ultra-smooth 60fps 3D scene perf
    if (this.lastRedrawMs >= 0 && nowMs - this.lastRedrawMs < 32) return;
    this.lastRedrawMs = nowMs;

    if (this.sourceKind === 'canvas2d') {
      if (this.customDraw) {
        this.customDraw(this.ctx, this.width, this.height, elapsedSeconds);
      } else {
        this.renderDefaultCanvas2D(elapsedSeconds);
      }
      this.canvasTexture.needsUpdate = true;
      return;
    }

    if (this.sourceKind === 'postMessage') {
      this.renderPostMessageFrame(elapsedSeconds);
      this.canvasTexture.needsUpdate = true;
      return;
    }

    if (this.sourceKind === 'message') {
      this.renderCustomMessageFrame(elapsedSeconds);
      this.canvasTexture.needsUpdate = true;
      return;
    }

    // Default: 'demo'
    this.renderDemoFrame(elapsedSeconds);
    this.canvasTexture.needsUpdate = true;
  }

  private drawSyntheticVideoStreamFrame(t: number): void {
    if (!this.syntheticVideoCanvas) return;
    const ctx = this.syntheticVideoCanvas.getContext('2d');
    if (!ctx) return;
    const W = this.syntheticVideoCanvas.width;
    const H = this.syntheticVideoCanvas.height;

    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, '#0033A0');
    grad.addColorStop(1, '#0284C7');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Animated broadcast wave bars
    ctx.fillStyle = 'rgba(245, 197, 66, 0.85)';
    for (let i = 0; i < 16; i++) {
      const h = 24 + Math.abs(Math.sin(t * 3.5 + i * 0.45)) * 75;
      ctx.fillRect(42 + i * 27, H - 30 - h, 16, h);
    }

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 34px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('WSTV HTMLVideoElement STREAM', W / 2, 56);
    ctx.font = 'bold 20px "JetBrains Mono", monospace';
    ctx.fillStyle = '#F5C542';
    ctx.fillText(`VIDEO TEXTURE LIVE · ${t.toFixed(1)}s`, W / 2, 92);
  }

  private renderDefaultCanvas2D(t: number): void {
    const ctx = this.ctx;
    const W = this.width;
    const H = this.height;

    ctx.fillStyle = '#04122B';
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = STADIUM_CONFIG.colors.goldBright;
    ctx.lineWidth = Math.max(3, H * 0.015);
    ctx.strokeRect(8, 8, W - 16, H - 16);

    ctx.fillStyle = '#F8FAFC';
    ctx.font = `bold ${Math.round(H * 0.14)}px "Barlow Condensed", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('CANVAS 2D LIVE FEED · WSTV', W / 2, H * 0.34);

    // Sweeping telemetry waveform
    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 4;
    ctx.beginPath();
    for (let x = 40; x < W - 40; x += 12) {
      const y = H * 0.68 + Math.sin(x * 0.025 + t * 5) * (H * 0.12);
      if (x === 40) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  private renderPostMessageFrame(t: number): void {
    const ctx = this.ctx;
    const W = this.width;
    const H = this.height;

    ctx.fillStyle = '#041029';
    ctx.fillRect(0, 0, W, H);

    if (this.postImage) {
      ctx.drawImage(this.postImage, 0, 0, W, H);
      return;
    }

    const p = this.lastPostPayload;
    ctx.fillStyle = '#0033A0';
    ctx.fillRect(0, 0, W, Math.round(H * 0.18));
    ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
    ctx.fillRect(0, Math.round(H * 0.18) - 4, W, 4);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${Math.round(H * 0.085)}px "Barlow Condensed", sans-serif`;
    ctx.textAlign = 'left';
    ctx.fillText(
      p?.title ?? 'POSTMESSAGE EXTERNAL FEED READY',
      28,
      Math.round(H * 0.12)
    );

    if (p?.clock) {
      ctx.textAlign = 'right';
      ctx.fillStyle = '#F5C542';
      ctx.font = `bold ${Math.round(H * 0.085)}px "JetBrains Mono", monospace`;
      ctx.fillText(p.clock, W - 28, Math.round(H * 0.12));
    }

    if (p?.rows && p.rows.length > 0 && !this.isRing) {
      p.rows.slice(0, 8).forEach((row, i) => {
        const y = H * 0.24 + i * (H * 0.09);
        ctx.fillStyle = 'rgba(255,255,255,0.06)';
        ctx.fillRect(24, y, W - 48, H * 0.075);
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'left';
        ctx.font = `600 ${Math.round(H * 0.048)}px "Plus Jakarta Sans", sans-serif`;
        ctx.fillText(row.label, 42, y + H * 0.052);
        ctx.textAlign = 'right';
        ctx.fillStyle = '#F5C542';
        ctx.fillText(row.value, W - 42, y + H * 0.052);
      });
    } else {
      ctx.textAlign = 'center';
      ctx.fillStyle = '#93C5FD';
      ctx.font = `600 ${Math.round(H * 0.075)}px "Plus Jakarta Sans", sans-serif`;
      ctx.fillText(
        p?.subtitle ?? `Listening on window.postMessage ({ type: "wstv-board" }) · ${t.toFixed(1)}s`,
        W / 2,
        H * 0.56
      );
    }
  }

  private renderCustomMessageFrame(t: number): void {
    const ctx = this.ctx;
    const W = this.width;
    const H = this.height;
    const msg = this.customMessage;
    const theme = msg.theme ?? 'royal';

    const palette =
      theme === 'gold'
        ? {
            bgTop: '#1E1603',
            bgBottom: '#3B2B05',
            header: '#D4AF37',
            headerText: '#041029',
            accent: '#F5C542',
            text: '#FFFBEB',
            subtext: '#FDE68A',
          }
        : theme === 'alert'
        ? {
            bgTop: '#2B0712',
            bgBottom: '#4C0519',
            header: '#DC2626',
            headerText: '#FFFFFF',
            accent: '#F5C542',
            text: '#FFFFFF',
            subtext: '#FECDD3',
          }
        : {
            bgTop: '#03122E',
            bgBottom: '#0A2963',
            header: '#0033A0',
            headerText: '#FFFFFF',
            accent: '#F5C542',
            text: '#FFFFFF',
            subtext: '#BAE6FD',
          };

    if (this.isRing) {
      ctx.fillStyle = palette.bgTop;
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = palette.accent;
      ctx.fillRect(0, 0, W, 7);
      ctx.fillRect(0, H - 7, W, 7);

      const strip = `${msg.title.toUpperCase()}${msg.body ? `   ·   ${msg.body}` : ''}   ·   WSTV   ·   `;
      ctx.font = 'bold 54px "Barlow Condensed", sans-serif';
      const tw = Math.max(400, ctx.measureText(strip).width);
      const offset = (t * 140) % tw;

      ctx.fillStyle = palette.text;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      for (let x = -offset; x < W; x += tw) {
        ctx.fillText(strip, x, H / 2 + 2);
      }
      return;
    }

    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, palette.bgTop);
    bg.addColorStop(1, palette.bgBottom);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Subtle decorative frame & corner brackets
    ctx.strokeStyle = palette.accent;
    ctx.lineWidth = 4;
    ctx.strokeRect(12, 12, W - 24, H - 24);

    // Header bar
    ctx.fillStyle = palette.header;
    ctx.fillRect(12, 12, W - 24, 64);
    ctx.fillStyle = palette.accent;
    ctx.fillRect(12, 74, W - 24, 4);

    ctx.fillStyle = palette.headerText;
    ctx.font = 'bold 28px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText('WSTV · KLEMONSERRAT STADIUM ANNOUNCEMENT', 32, 46);

    const nowStr = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    ctx.textAlign = 'right';
    ctx.font = 'bold 28px "JetBrains Mono", monospace';
    ctx.fillText(nowStr, W - 32, 46);

    // Main Headline (auto-scaled + wrapped if long)
    ctx.fillStyle = palette.accent;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const titleLines = wrapCanvasLines(ctx, msg.title.toUpperCase(), W - 110, 'bold 74px "Barlow Condensed", sans-serif', 2);
    const titleStartY = msg.body ? H * 0.34 : H * 0.48;
    const titleLineH = 74;
    ctx.font = 'bold 74px "Barlow Condensed", sans-serif';
    titleLines.forEach((line, idx) => {
      const y = titleStartY + (idx - (titleLines.length - 1) / 2) * titleLineH;
      ctx.fillText(line, W / 2, y);
    });

    // Body Message (multi-line wrapped)
    if (msg.body) {
      const bodyLines = wrapCanvasLines(
        ctx,
        msg.body,
        W - 140,
        '600 34px "Plus Jakarta Sans", sans-serif',
        4
      );
      ctx.fillStyle = palette.text;
      ctx.font = '600 34px "Plus Jakarta Sans", sans-serif';
      const bodyTop = titleStartY + titleLines.length * 44 + 28;
      bodyLines.forEach((line, idx) => {
        ctx.fillText(line, W / 2, bodyTop + idx * 44);
      });
    }

    // Bottom animated ticker bar
    const tickerText =
      msg.ticker || '1ST PACIFICA REGIONAL OLYMPICS 2026  ·  PLEAD CITY, NEW PLEADLAND  ·  WSTV';
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.fillRect(14, H - 62, W - 28, 48);
    ctx.fillStyle = palette.subtext;
    ctx.font = 'bold 24px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(tickerText, W / 2, H - 38);
  }

  /**
   * Built-in Demo Content:
   * - Ring board: crisp scrolling stadium banner + live clock
   * - Main / End boards: scoreboard graphics, 8-lane list, running clock,
   *   and an animated 2D oval track simulation with 8 colored runner dots!
   */
  private renderDemoFrame(t: number): void {
    const ctx = this.ctx;
    const W = this.width;
    const H = this.height;

    if (this.isRing) {
      ctx.fillStyle = '#031233';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
      ctx.fillRect(0, 0, W, 6);
      ctx.fillRect(0, H - 6, W, 6);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 52px "Barlow Condensed", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const nowStr = new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      ctx.fillText(
        `KLEMONSERRAT STADIUM  ·  1ST PACIFICA REGIONAL OLYMPICS 2026  ·  WSTV LIVE  ·  ${nowStr}`,
        W / 2,
        H / 2 + 2
      );
      return;
    }

    // Main / End-zone LED Board layout
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#04122B');
    bg.addColorStop(1, '#092354');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Header
    ctx.fillStyle = '#0033A0';
    ctx.fillRect(0, 0, W, 72);
    ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
    ctx.fillRect(0, 68, W, 4);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 30px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('WSTV · 1ST PACIFICA REGIONAL OLYMPICS 2026', 24, 46);

    // Live running clock
    const lapClock = t % 45.0;
    ctx.textAlign = 'right';
    ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
    ctx.font = 'bold 36px "JetBrains Mono", monospace';
    ctx.fillText(`${lapClock.toFixed(2).padStart(5, '0')}s`, W - 24, 48);

    // Left Half: 8-Lane Lineup Demo List
    const nations = STADIUM_CONFIG.pacificaNations;
    for (let i = 0; i < 8; i++) {
      const y = 92 + i * 49;
      const nat = nations[i % nations.length];
      ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.025)';
      ctx.fillRect(24, y, W * 0.48, 42);

      ctx.fillStyle = nat.primary;
      ctx.fillRect(24, y, 8, 42);

      ctx.textAlign = 'left';
      ctx.fillStyle = '#F5C542';
      ctx.font = 'bold 22px "JetBrains Mono", monospace';
      ctx.fillText(`L${i + 1}`, 42, y + 29);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 24px "Barlow Condensed", sans-serif';
      ctx.fillText(`${nat.code} · ${nat.name.toUpperCase()}`, 88, y + 29);
    }

    // Right Half: Animated 2D Demo Oval Simulation (8 dots moving around 400m loop)
    const boxX = W * 0.53;
    const boxY = 92;
    const boxW = W * 0.445;
    const boxH = H - 116;

    ctx.fillStyle = 'rgba(2, 6, 23, 0.55)';
    ctx.fillRect(boxX, boxY, boxW, boxH);
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.45)';
    ctx.lineWidth = 2;
    ctx.strokeRect(boxX, boxY, boxW, boxH);

    ctx.fillStyle = '#93C5FD';
    ctx.font = 'bold 20px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('LIVE 2D TRACK FEED (DEMO LOOP)', boxX + boxW / 2, boxY + 28);

    // Draw mini oval track
    const cx = boxX + boxW / 2;
    const cy = boxY + boxH * 0.55;
    const straightHalf = boxW * 0.18;
    const rad = boxH * 0.25;

    ctx.strokeStyle = '#1551A1';
    ctx.lineWidth = 32;
    ctx.beginPath();
    ctx.moveTo(cx - straightHalf, cy - rad);
    ctx.lineTo(cx + straightHalf, cy - rad);
    ctx.arc(cx + straightHalf, cy, rad, -Math.PI / 2, Math.PI / 2);
    ctx.lineTo(cx - straightHalf, cy + rad);
    ctx.arc(cx - straightHalf, cy, rad, Math.PI / 2, Math.PI * 1.5);
    ctx.closePath();
    ctx.stroke();

    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Animate 8 colored runner dots smoothly around the closed 2D oval
    const totalPerim = 4 * straightHalf + 2 * Math.PI * rad;
    for (let lane = 0; lane < 8; lane++) {
      const speed = 0.24 + (7 - lane) * 0.008 + Math.sin(t + lane) * 0.004;
      const u = ((t * speed + lane * 0.03) % 1) * totalPerim;
      const rLane = rad - 10 + lane * 3;
      let dx = cx;
      let dy = cy;

      const s1 = 2 * straightHalf;
      const c1 = Math.PI * rad;
      if (u < s1) {
        dx = cx - straightHalf + u;
        dy = cy + rLane;
      } else if (u < s1 + c1) {
        const a = Math.PI / 2 - ((u - s1) / c1) * Math.PI;
        dx = cx + straightHalf + Math.cos(a) * rLane;
        dy = cy + Math.sin(a) * rLane;
      } else if (u < 2 * s1 + c1) {
        dx = cx + straightHalf - (u - s1 - c1);
        dy = cy - rLane;
      } else {
        const a = -Math.PI / 2 - ((u - 2 * s1 - c1) / c1) * Math.PI;
        dx = cx - straightHalf + Math.cos(a) * rLane;
        dy = cy + Math.sin(a) * rLane;
      }

      ctx.fillStyle = lane === 0 ? '#F5C542' : lane % 2 === 0 ? '#FFFFFF' : '#38BDF8';
      ctx.beginPath();
      ctx.arc(dx, dy, 6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  public dispose(): void {
    this.mesh.geometry.dispose();
    this.material.dispose();
    this.canvasTexture.dispose();
    this.videoTexture?.dispose();
  }
}

function wrapCanvasLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  font: string,
  maxLines: number
): string[] {
  ctx.font = font;
  const paragraphs = text.split(/\r?\n/);
  const lines: string[] = [];

  for (const para of paragraphs) {
    const words = para.trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) continue;
    let current = words[0];
    for (let i = 1; i < words.length; i++) {
      const next = `${current} ${words[i]}`;
      if (ctx.measureText(next).width <= maxWidth) {
        current = next;
      } else {
        lines.push(current);
        current = words[i];
        if (lines.length >= maxLines) break;
      }
    }
    if (lines.length < maxLines) {
      lines.push(current);
    }
    if (lines.length >= maxLines) break;
  }

  return lines.slice(0, maxLines);
}
