import * as THREE from 'three';
import { STADIUM_CONFIG } from '../config';
import {
  getTrackPath,
  HALF_STRAIGHT,
  KERB_RADIUS,
  OUTER_TRACK_RADIUS,
} from '../track/trackGeometry';
import {
  createPerson,
  PersonInstance,
  PersonOptions,
  PersonPoseName,
  PersonType,
  updatePersonPose,
} from './PersonFactory';

const MEN_NAMES = [
  'K. Tuiasosopo',
  'M. Ravouvou',
  'S. Vaioleti',
  'L. Henderson',
  'T. Te Aho',
  'J. Naisara',
  'R. Manuleleua',
  'K. Wari',
];

const WOMEN_NAMES = [
  'S. Kora',
  'M. Latu',
  'T. Vaioleti',
  'C. Whittaker',
  'A. Ngata',
  'A. Naisara',
  'L. Taumoepeau',
  'R. Malakai',
];

const SKIN_TONES = ['#6D442B', '#8D5524', '#A5694F', '#C68642', '#E0AC69', '#F1C27D'];

/**
 * Manages all stadium personnel: 8 men & 8 women runners (warm-up/idle/jog only),
 * officials, medical & timing staff, volunteers, media photographers, and commentators.
 * Exposes spawnPerson / removePerson / setPose for the Extension API.
 */
export class PeopleManager {
  public readonly group = new THREE.Group();
  private people = new Map<string, PersonInstance>();
  private labelsVisible = true;

  constructor() {
    this.group.name = 'StadiumPeople';
    this.populateDefaultVenuePeople();
  }

  public spawnPerson(type: PersonType, options: PersonOptions = {}): string {
    const person = createPerson(type, {
      ...options,
      showLabel: options.showLabel ?? this.labelsVisible,
    });
    if (this.people.has(person.id)) {
      this.removePerson(person.id);
    }
    this.people.set(person.id, person);
    this.group.add(person.root);
    return person.id;
  }

  public removePerson(id: string): boolean {
    const p = this.people.get(id);
    if (!p) return false;
    this.group.remove(p.root);
    p.dispose();
    this.people.delete(id);
    return true;
  }

  public setPose(id: string, poseName: PersonPoseName): boolean {
    const p = this.people.get(id);
    if (!p) return false;
    p.pose = poseName;
    return true;
  }

  public getAll(): PersonInstance[] {
    return Array.from(this.people.values());
  }

  public setLabelsVisible(visible: boolean): void {
    this.labelsVisible = visible;
    this.people.forEach((p) => {
      if (p.labelSprite) p.labelSprite.visible = visible;
    });
  }

  private populateDefaultVenuePeople(): void {
    const yTrack = STADIUM_CONFIG.track.trackSurfaceY;
    const yTurf = STADIUM_CONFIG.track.infieldTurfY;
    const nations = STADIUM_CONFIG.pacificaNations;

    // 1. 8 Men Runners (lanes 1-8, warming up / stretching / gently jogging — NO racing)
    const menPoses: PersonPoseName[] = [
      'jog',
      'stretch',
      'warmup',
      'idle',
      'jog',
      'warmup',
      'stretch',
      'jog',
    ];
    for (let i = 0; i < 8; i++) {
      const nat = nations[i % nations.length];
      const pose = menPoses[i];
      const path = getTrackPath(i + 1);
      const startDist = 12 + i * 18;
      const pt = path.pointAt(startDist);

      this.spawnPerson('runner', {
        id: `runner-men-${i + 1}`,
        gender: 'men',
        name: MEN_NAMES[i],
        number: String(101 + i),
        kitPrimary: nat.primary,
        kitSecondary: nat.secondary,
        skinTone: SKIN_TONES[i % SKIN_TONES.length],
        pose,
        position: [pt.position.x, yTrack, pt.position.z],
        heading: pt.heading,
        jogLane: pose === 'jog' ? i + 1 : undefined,
        jogOffsetMeters: startDist,
        jogSpeedMps: 2.8 + (i % 3) * 0.45,
      });
    }

    // 2. 8 Women Runners (warming up on back straight & infield warm-up lane)
    const womenPoses: PersonPoseName[] = [
      'warmup',
      'jog',
      'stretch',
      'jog',
      'idle',
      'stretch',
      'jog',
      'warmup',
    ];
    for (let i = 0; i < 8; i++) {
      const nat = nations[(i + 3) % nations.length];
      const pose = womenPoses[i];
      const path = getTrackPath(i + 1);
      const startDist = 210 + i * 16;
      const pt = path.pointAt(startDist);

      this.spawnPerson('runner', {
        id: `runner-women-${i + 1}`,
        gender: 'women',
        name: WOMEN_NAMES[i],
        number: String(201 + i),
        kitPrimary: nat.primary,
        kitSecondary: nat.secondary,
        skinTone: SKIN_TONES[(i + 2) % SKIN_TONES.length],
        pose,
        position: [pt.position.x, yTrack, pt.position.z],
        heading: pt.heading,
        jogLane: pose === 'jog' ? i + 1 : undefined,
        jogOffsetMeters: startDist,
        jogSpeedMps: 2.6 + (i % 3) * 0.4,
      });
    }

    // 3. Officials (starter, finish judges, lane marshals, timing staff)
    const officialsCoords: Array<{ pos: [number, number, number]; heading: number; name?: string }> = [
      { pos: [-HALF_STRAIGHT - 2, yTrack, OUTER_TRACK_RADIUS + 2.1], heading: Math.PI, name: 'Starter' },
      { pos: [HALF_STRAIGHT + 0.6, yTrack, KERB_RADIUS - 2.3], heading: 0, name: 'Finish Judge' },
      { pos: [HALF_STRAIGHT - 0.8, yTrack, KERB_RADIUS - 2.3], heading: 0 },
      { pos: [HALF_STRAIGHT + 1.4, yTrack, OUTER_TRACK_RADIUS + 1.9], heading: Math.PI, name: 'Timing Staff' },
      { pos: [0, yTrack, KERB_RADIUS - 2.2], heading: 0, name: 'Lane Marshal' },
      { pos: [-26, yTrack, -KERB_RADIUS + 2.2], heading: Math.PI, name: 'Lane Marshal' },
      // Seated at infield officials' tables
      { pos: [11, yTurf, 12.2], heading: 0 },
      { pos: [13, yTurf, 12.2], heading: 0 },
      { pos: [-16, yTurf, -11.2], heading: Math.PI },
    ];
    officialsCoords.forEach((o, idx) => {
      this.spawnPerson('official', {
        id: `official-${idx + 1}`,
        gender: idx % 2 === 0 ? 'men' : 'women',
        pose: idx >= 6 ? 'seated' : 'idle',
        position: o.pos,
        heading: o.heading,
        name: o.name,
      });
    });

    // 4. Medical Staff & Blue-Uniform Volunteers
    [
      { pos: [36, yTrack, OUTER_TRACK_RADIUS + 2.5] as [number, number, number], heading: Math.PI },
      { pos: [-38, yTrack, OUTER_TRACK_RADIUS + 2.5] as [number, number, number], heading: Math.PI },
    ].forEach((m, idx) => {
      this.spawnPerson('medical', {
        id: `medical-${idx + 1}`,
        gender: idx === 0 ? 'women' : 'men',
        pose: 'idle',
        position: m.pos,
        heading: m.heading,
        name: 'Medical',
      });
    });

    [
      [-12, yTrack, OUTER_TRACK_RADIUS + 2.4, Math.PI],
      [18, yTrack, OUTER_TRACK_RADIUS + 2.4, Math.PI],
      [-55, yTrack, 0, Math.PI / 2],
      [55, yTrack, 0, -Math.PI / 2],
    ].forEach(([vx, vy, vz, h], idx) => {
      this.spawnPerson('volunteer', {
        id: `volunteer-${idx + 1}`,
        gender: idx % 2 === 0 ? 'women' : 'men',
        pose: 'idle',
        position: [vx, vy, vz],
        heading: h,
      });
    });

    // 5. Media (camera operators, photographers, commentators in commentary box)
    const mediaSpots: Array<{ pos: [number, number, number]; heading: number; cam: boolean }> = [
      { pos: [HALF_STRAIGHT + 6.5, yTrack, OUTER_TRACK_RADIUS + 2.5], heading: -Math.PI * 0.72, cam: true },
      { pos: [-14, yTrack, KERB_RADIUS - 2.1], heading: 0.15, cam: true },
      { pos: [-44, yTrack, OUTER_TRACK_RADIUS + 2.6], heading: Math.PI * 0.75, cam: true },
      { pos: [HALF_STRAIGHT + 3.2, yTrack, KERB_RADIUS - 1.9], heading: -0.5, cam: true },
    ];
    mediaSpots.forEach((m, idx) => {
      this.spawnPerson('media', {
        id: `media-${idx + 1}`,
        pose: 'camera',
        hasCamera: m.cam,
        position: m.pos,
        heading: m.heading,
        name: idx === 0 ? 'WSTV Cam' : undefined,
      });
    });

    // Commentators inside VIP/Media box overlooking home straight
    const tier2Y =
      1.4 + STADIUM_CONFIG.stadium.tier1Rows * STADIUM_CONFIG.stadium.rowRise + 2.0;
    const tier2R =
      OUTER_TRACK_RADIUS +
      STADIUM_CONFIG.stadium.bowlInnerOffset +
      STADIUM_CONFIG.stadium.tier1Rows * STADIUM_CONFIG.stadium.rowDepth +
      STADIUM_CONFIG.stadium.concourseGap;
    [-4, -1.5].forEach((cx, idx) => {
      this.spawnPerson('commentator', {
        id: `commentator-${idx + 1}`,
        pose: 'seated',
        position: [cx, tier2Y - 0.8, tier2R - 2.5],
        heading: Math.PI,
        name: idx === 0 ? 'WSTV Commentary' : undefined,
      });
    });
  }

  public update(elapsedSeconds: number, dt: number): void {
    const yTrack = STADIUM_CONFIG.track.trackSurfaceY;
    this.people.forEach((p) => {
      if (p.pose === 'jog' && p.options.jogLane) {
        const speed = p.options.jogSpeedMps ?? 2.8;
        p.jogDistance += speed * dt;
        const path = getTrackPath(p.options.jogLane);
        const pt = path.pointAt(p.jogDistance);
        p.root.position.set(pt.position.x, yTrack, pt.position.z);
        p.root.rotation.y = pt.heading;
      }
      updatePersonPose(p, elapsedSeconds, dt);
    });
  }

  public dispose(): void {
    this.people.forEach((p) => {
      this.group.remove(p.root);
      p.dispose();
    });
    this.people.clear();
  }
}
