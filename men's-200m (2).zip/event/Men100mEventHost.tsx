import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { StadiumAPI } from '../src/api/StadiumAPI';
import { MockWavesportsApi } from './api/MockWavesportsApi';
import {
  HttpWavesportsApiClient,
  RealtimeWavesportsApiClient,
  type WavesportsApiClient,
} from './api/WavesportsApiClient';
import { getEventConfig, STADIUM_INTEGRITY_CALLS } from './config';
import {
  RaceController,
  type RaceControllerUIState,
} from './sim/RaceController';
import { EventPanel } from './ui/EventPanel';

interface Men100mEventHostProps {
  api: StadiumAPI;
}

export const Men100mEventHost: React.FC<Men100mEventHostProps> = ({ api }) => {
  const config = useMemo(() => getEventConfig(), []);
  const controllerRef = useRef<RaceController | null>(null);
  const [controller, setController] = useState<RaceController | null>(null);
  const [uiState, setUiState] = useState<RaceControllerUIState | null>(null);

  useEffect(() => {
    console.info(
      '[Stadium Integrity] Men100m event initialized additively inside EventLayer_Men100m. No stadium file or object was modified. API calls used:',
      STADIUM_INTEGRITY_CALLS
    );

    let client: WavesportsApiClient;
    if (import.meta.env.DEV && config.MOCK_API) {
      client = new MockWavesportsApi({
        seedOverride: config.SEED_OVERRIDE,
        cleanRace: config.CLEAN_RACE_OVERRIDE,
      });
    } else if (config.REALTIME_TRANSPORT !== 'none') {
      client = new RealtimeWavesportsApiClient(
        config.API_BASE_URL,
        config.API_TOKEN,
        config.REALTIME_TRANSPORT
      );
    } else {
      client = new HttpWavesportsApiClient(
        config.API_BASE_URL,
        config.API_TOKEN
      );
    }

    const ctrl = new RaceController({
      stadium: api,
      apiClient: client,
      raceId: config.RACE_ID,
      pollIntervalMs: config.POLL_INTERVAL_MS,
      onUIUpdate: (next) => setUiState(next),
    });

    controllerRef.current = ctrl;
    setController(ctrl);

    return () => {
      ctrl.dispose();
      controllerRef.current = null;
      setController(null);
    };
  }, [api, config]);

  if (!controller || !uiState) return null;

  return (
    <EventPanel
      controller={controller}
      uiState={uiState}
      adminModeFromUrl={config.ADMIN_MODE}
    />
  );
};
