# Men's 100m Race Event — Powered by Wavesports AI (WSTV)

Additive **Men's 100 Metres** race broadcast module built cleanly beside the unmodified **3D Klemonserrat Stadium** for the **1st Pacifica Regional Olympics 2026**.

---

## 1. Placing the Event Next to the Stadium

All event code lives inside `/event/` alongside the unmodified stadium `/src/` directory:

- `event/config/` — API URL/token/poll settings (`index.ts`) and incident rates (`incidents.ts`)
- `event/api/` — TypeScript contract (`types.ts`), strict payload validator (`validation.ts`), HTTP & SSE/WebSocket clients (`WavesportsApiClient.ts`), and dev-only mock (`MockWavesportsApi.ts`)
- `event/ai/` — Deterministic seeded PRNG (`seededRng.ts`), pluggable broadcast commentary (`commentary.ts`), and race physics + incident planner (`WavesportsAI.ts`)
- `event/sim/` — 30 Hz fixed-timestep loop (`FixedStepLoop.ts`), additive 100m track extension & props (`TrackExtension.ts`), procedural Web Audio gun FX (`AudioFX.ts`), and state machine (`RaceController.ts`)
- `event/athletes/` — Stadium `spawnPerson` wrapper & idle-runner restoration (`AthleteManager.ts`) and articulated race animations (`AthleteAnimator.ts`)
- `event/director/` — LED scoreboard/PIP controller (`BoardController.ts`) and Auto Director + 6 event cameras (`BroadcastDirector.ts`)
- `event/ui/` — Glassmorphism HUD overlay (`EventPanel.tsx`) and entry host (`Men100mEventHost.tsx`)

### Entry Wiring (`src/App.tsx`)
Only two lines were added to `src/App.tsx`:
1. `import { Men100mEventHost } from '../event/Men100mEventHost';`
2. `{ready && api && <Men100mEventHost api={api} />}`

---

## 2. Running in Production vs. Dev Mock Mode

By default, the app boots in `WAITING_FOR_API` (stadium visible and orbitable, no athletes spawned, boards displaying `"MEN'S 100 METRES – WAITING FOR WAVESPORTS API"`).

### Dev-Only Mock Mode (`?mock=1`)
`MockWavesportsApi` is **off by default** and **disabled in production builds** (`import.meta.env.DEV` guard). In development (`npm run dev`), append query flags:
- `?mock=1` — Enables `MockWavesportsApi` (displays a visible `MOCK API – DEV ONLY` badge)
- `?mock=1&mode=admin` — Shows Broadcast Admin Controls (Manual Start, Camera Director, Replay `1x` / `0.25x`, Reset View, Mock Start/Reset/New Seed buttons)
- `?mock=1&seed=123456` — Tests a specific deterministic seed
- `?mock=1&clean=1` — Sets all incident probabilities to `0` for a clean race

---

## 3. Configuring Base URL, Token, Race ID & Realtime Transport

Edit `event/config/index.ts` or provide Vite environment variables:

```env
VITE_WAVESPORTS_API_BASE_URL=https://api.wavesports.tv/v1
VITE_WAVESPORTS_API_TOKEN=your_bearer_token
VITE_WAVESPORTS_RACE_ID=men-100m-final-1
VITE_WAVESPORTS_POLL_MS=2500
```

You can also override at runtime with URL params: `?apiBase=...&race=...&realtime=sse` (or `ws`). See `docs/api-contract.md` for the full HTTP/Realtime schema.

---

## 4. Incident Probabilities & Overrides

Default per-athlete / per-attempt probabilities live in `event/config/incidents.ts`:
- `falseStartBaseRate`: `0.028` (reaction < `0.100s` or pre-gun movement; max 3 recalls)
- `stumbledStartRate`: `0.035`
- `fallOrTripRate`: `0.012` (DNF)
- `injuryPullUpRate`: `0.010` (DNF)
- `laneViolationRate`: `0.008` (DQ)
- `collisionBrushRate`: `0.006`
- `lateDnsRate`: `0.005`
- `equipmentBlockSlipRate`: `0.007` (recall without DQ)
- `breakoutPerformanceRate`: `0.045`
- `maxRecalls`: `3`

Override any value per race via `setup.incidentOverrides` in the API payload (or pass `0` to guarantee a clean race).

---

## 5. Stadium API Gaps Worked Around Additively

1. **Missing `addRenderCallback` & `sim.pause/resume/setTimeScale`**: `StadiumAPI` only provides `addUpdateCallback`. `event/sim/FixedStepLoop.ts` layers a deterministic `1/30 s` fixed-timestep accumulator, `pause()`/`resume()`/`setTimeScale()`, and render-interpolation callbacks on top of `stadium.addUpdateCallback`.
2. **84.39 m Home Straight vs. 100.00 m Distance**: `stadium.getTrackPath(lane)` covers an 84.39 m straight; querying `< 0` wraps around the west bend. `event/sim/TrackExtension.ts` measures 100.00 m back from `pointAt(84.39)` and adds a matching blue 15.61 m straight run-up extension, white lane lines, 100m start line, starting blocks, wind gauge, wind flags, and starter FX inside `THREE.Group('EventLayer_Men100m')`.
3. **Missing Race Poses & Kit Accent**: `PersonFactory` only loops `idle | stretch | warmup | jog | seated | camera`. `event/athletes/AthleteAnimator.ts` drives articulated joint poses (`walkout`, `stretch_shakeout`, `on_your_marks`, `set_crouch`, `false_start_twitch`, `sprint`, `stumble`, `fall_slide`, `pull_up_injured`, `limp`, `lean_finish`, `celebrate`, `disappointed`) after `PeopleManager.update()` runs, and attaches an additive `kit.accent` sash mesh to `person.torso`.
4. **Missing `board.setText / addText / clearText`**: `BoardScreen` provides `setMessage` and `setSource('canvas2d' | 'renderTarget')`. `event/director/BoardController.ts` wraps `stadium.boards.get(name)` with `setText/addText/clearText` helpers, live 2D broadcast scoreboards, and an optional secondary `WebGLRenderTarget` mini-view on `westBoard`.
5. **Custom Event Cameras vs. OrbitControls**: `StadiumAPI.cameras.goTo` only accepts 8 static presets. `event/director/BroadcastDirector.ts` drives 6 dynamic event cameras (`blocksHeadOn`, `trackingRail`, `finishLine`, `photoFinish`, `replayCam`, `overhead`) after `CameraController.update()` and yields immediately on `pointerdown` / `wheel` / `touchstart` so OrbitControls always remains responsive.

---

## 6. Stadium Integrity Statement

**No stadium file or object was modified.** Every stadium mesh, track curve, lighting rig, crowd instance, board frame, camera controller, and default UI component remains untouched. All 3D race props reside inside the single additive `THREE.Group` named `EventLayer_Men100m`, and all temporary warm-up runner suspensions are cleanly restored via `stadium.people.spawnPerson` on reset or unmount.
