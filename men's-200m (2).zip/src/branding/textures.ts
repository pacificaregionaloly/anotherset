import * as THREE from 'three';
import { STADIUM_CONFIG } from '../config';

/**
 * Draws a crisp vector black rampant lion crest onto any 2D Canvas.
 */
export function drawRampantLion(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scale: number,
  color = '#0A0D14'
): void {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);
  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  // Torso
  ctx.beginPath();
  ctx.moveTo(-8, -32);
  ctx.bezierCurveTo(-18, -18, -14, 12, 4, 34);
  ctx.bezierCurveTo(16, 46, 22, 22, 16, 2);
  ctx.bezierCurveTo(14, -14, 8, -28, -8, -32);
  ctx.fill();

  // Head & open jaw
  ctx.beginPath();
  ctx.arc(-4, -40, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-12, -46);
  ctx.lineTo(-28, -43);
  ctx.lineTo(-22, -37);
  ctx.lineTo(-15, -39);
  ctx.lineTo(-24, -33);
  ctx.lineTo(-14, -30);
  ctx.closePath();
  ctx.fill();

  // Mane
  ctx.beginPath();
  ctx.moveTo(4, -52);
  ctx.quadraticCurveTo(18, -46, 14, -32);
  ctx.quadraticCurveTo(22, -26, 12, -18);
  ctx.lineTo(4, -26);
  ctx.closePath();
  ctx.fill();

  // Upper & lower forelegs
  ctx.lineWidth = 6.5;
  ctx.beginPath();
  ctx.moveTo(-10, -22);
  ctx.quadraticCurveTo(-28, -28, -38, -34);
  ctx.stroke();

  ctx.lineWidth = 2.5;
  for (let i = -1; i <= 1; i++) {
    ctx.beginPath();
    ctx.moveTo(-38, -34 + i * 2);
    ctx.lineTo(-44, -37 + i * 3);
    ctx.stroke();
  }

  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(-8, -6);
  ctx.quadraticCurveTo(-24, -4, -33, -10);
  ctx.stroke();

  // Hind legs
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(2, 14);
  ctx.quadraticCurveTo(-18, 12, -24, 24);
  ctx.lineTo(-34, 26);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(12, 26);
  ctx.quadraticCurveTo(16, 44, 14, 58);
  ctx.lineTo(4, 62);
  ctx.stroke();

  // S-curved tail
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.moveTo(15, 20);
  ctx.bezierCurveTo(38, 22, 46, -12, 30, -22);
  ctx.bezierCurveTo(20, -26, 18, -12, 26, -8);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(25, -8, 4.5, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * Draws the 1st Pacifica Regional Olympics 2026 emblem:
 * - Royal blue / white shield with black rampant lion
 * - Green top panel with white hornbill
 * - Turquoise Pacific waves flanking shield
 * - Laurel branches, golden torch, ring text "1ST PACIFICA REGIONAL OLYMPICS"
 * - Banner "2026 NEW PLEADLAND"
 */
export function drawPacificaEmblem(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number
): void {
  ctx.save();
  ctx.translate(cx, cy);
  const s = radius / 220;
  ctx.scale(s, s);

  // Outer white disc & gold rim
  ctx.beginPath();
  ctx.arc(0, 0, 212, 0, Math.PI * 2);
  ctx.fillStyle = '#F8FAFC';
  ctx.fill();
  ctx.lineWidth = 8;
  ctx.strokeStyle = STADIUM_CONFIG.colors.gold;
  ctx.stroke();

  // Laurel wreaths
  ctx.fillStyle = '#0B5D4B';
  for (const side of [-1, 1]) {
    for (let i = 0; i < 11; i++) {
      const angle = 0.48 + i * 0.17;
      const lx = side * Math.sin(angle) * 168;
      const ly = Math.cos(angle) * 168;
      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate(side * (-angle + 0.6));
      ctx.beginPath();
      ctx.ellipse(0, 0, 7, 17, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  // Ocean waves on both sides
  for (const side of [-1, 1]) {
    ctx.save();
    ctx.scale(side, 1);
    ctx.fillStyle = '#2A8BB8';
    ctx.beginPath();
    ctx.moveTo(72, -10);
    ctx.bezierCurveTo(118, -75, 165, -85, 172, -45);
    ctx.bezierCurveTo(140, -60, 110, -25, 95, 25);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#5BB4D4';
    ctx.beginPath();
    ctx.moveTo(74, 15);
    ctx.bezierCurveTo(122, -40, 155, -35, 162, -10);
    ctx.bezierCurveTo(132, -20, 108, 10, 92, 42);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // Central blue/white shield + rampant lion
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-78, -82);
  ctx.lineTo(78, -82);
  ctx.lineTo(78, 20);
  ctx.quadraticCurveTo(75, 95, 0, 132);
  ctx.quadraticCurveTo(-75, 95, -78, 20);
  ctx.closePath();
  ctx.clip();

  ctx.fillStyle = STADIUM_CONFIG.colors.newPleadlandBlue;
  ctx.fillRect(-85, -90, 85, 230);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, -90, 85, 230);
  drawRampantLion(ctx, 0, 18, 1.05, '#0A0D14');
  ctx.restore();

  ctx.beginPath();
  ctx.moveTo(-78, -82);
  ctx.lineTo(78, -82);
  ctx.lineTo(78, 20);
  ctx.quadraticCurveTo(75, 95, 0, 132);
  ctx.quadraticCurveTo(-75, 95, -78, 20);
  ctx.closePath();
  ctx.lineWidth = 6;
  ctx.strokeStyle = '#061B44';
  ctx.stroke();

  // Green top panel with white hornbill
  ctx.beginPath();
  ctx.moveTo(-36, -148);
  ctx.lineTo(36, -148);
  ctx.lineTo(36, -98);
  ctx.quadraticCurveTo(34, -76, 0, -68);
  ctx.quadraticCurveTo(-34, -76, -36, -98);
  ctx.closePath();
  ctx.fillStyle = '#08963A';
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.strokeStyle = '#061B44';
  ctx.stroke();

  // White hornbill silhouette
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.ellipse(-2, -102, 10, 16, 0.35, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(3, -122, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(6, -126);
  ctx.quadraticCurveTo(24, -126, 22, -118);
  ctx.lineTo(7, -118);
  ctx.closePath();
  ctx.fill();

  // Golden torch
  ctx.fillStyle = '#0A2558';
  ctx.beginPath();
  ctx.moveTo(-14, 108);
  ctx.lineTo(14, 108);
  ctx.lineTo(6, 152);
  ctx.lineTo(-6, 152);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#D99B1C';
  ctx.beginPath();
  ctx.moveTo(-16, 104);
  ctx.quadraticCurveTo(-22, 74, -4, 58);
  ctx.quadraticCurveTo(0, 74, 4, 50);
  ctx.quadraticCurveTo(22, 72, 16, 104);
  ctx.closePath();
  ctx.fill();

  // Bottom banner "2026 NEW PLEADLAND"
  ctx.fillStyle = '#061B44';
  ctx.beginPath();
  ctx.moveTo(-124, 148);
  ctx.quadraticCurveTo(0, 184, 124, 148);
  ctx.lineTo(114, 178);
  ctx.quadraticCurveTo(0, 212, -114, 178);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#061B44';
  ctx.font = 'bold 26px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('2026', 0, 156);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 22px "Barlow Condensed", sans-serif';
  ctx.fillText('NEW PLEADLAND', 0, 185);

  // Ring text "1ST PACIFICA REGIONAL OLYMPICS"
  const topText = '1ST PACIFICA REGIONAL OLYMPICS';
  ctx.fillStyle = '#061B44';
  ctx.font = 'bold 22px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const startA = -Math.PI * 0.82;
  const endA = -Math.PI * 0.18;
  for (let i = 0; i < topText.length; i++) {
    const t = i / (topText.length - 1);
    const a = startA + t * (endA - startA);
    ctx.save();
    ctx.rotate(a + Math.PI / 2);
    ctx.fillText(topText[i], 0, -182);
    ctx.restore();
  }

  ctx.restore();
}

/**
 * Draws the Wavesports Television (WSTV) brand mark in blue, white & gold.
 */
export function drawWSTVLogo(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number
): void {
  ctx.fillStyle = '#041436';
  ctx.fillRect(0, 0, w, h);

  // Gold top/bottom borders
  ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
  ctx.fillRect(0, 0, w, Math.max(4, h * 0.03));
  ctx.fillRect(0, h - Math.max(4, h * 0.03), w, Math.max(4, h * 0.03));

  const cx = w * 0.5;
  const cy = h * 0.36;
  const s = Math.min(w, h) / 260;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);

  const grad = ctx.createLinearGradient(-70, -40, 70, 40);
  grad.addColorStop(0, '#1D68C4');
  grad.addColorStop(1, '#38BDF8');
  ctx.fillStyle = grad;

  ctx.beginPath();
  ctx.moveTo(-78, 12);
  ctx.bezierCurveTo(-72, -38, -22, -55, 8, -28);
  ctx.bezierCurveTo(-18, -32, -40, -10, -34, 16);
  ctx.bezierCurveTo(-18, 28, 6, 8, 18, -10);
  ctx.lineTo(28, 16);
  ctx.lineTo(54, -22);
  ctx.lineTo(68, -22);
  ctx.lineTo(30, 34);
  ctx.lineTo(12, 8);
  ctx.bezierCurveTo(-14, 44, -68, 42, -78, 12);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.moveTo(-26, -12);
  ctx.lineTo(-10, -2);
  ctx.lineTo(-26, 8);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = '#38BDF8';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  for (let r = 18; r <= 38; r += 10) {
    ctx.beginPath();
    ctx.arc(22, -26, r, -Math.PI * 0.42, -Math.PI * 0.05);
    ctx.stroke();
  }

  ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
  ctx.beginPath();
  ctx.moveTo(0, -56);
  ctx.lineTo(4, -45);
  ctx.lineTo(15, -41);
  ctx.lineTo(4, -37);
  ctx.lineTo(0, -26);
  ctx.lineTo(-4, -37);
  ctx.lineTo(-15, -41);
  ctx.lineTo(-4, -45);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = `800 ${Math.round(h * 0.15)}px "Barlow Condensed", sans-serif`;
  ctx.textAlign = 'center';
  ctx.fillText('WAVESPORTS', cx, h * 0.72);

  ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
  ctx.font = `700 ${Math.round(h * 0.08)}px "Plus Jakarta Sans", sans-serif`;
  ctx.fillText('W S T V  ·  T E L E V I S I O N', cx, h * 0.86);
}

function applySlotOverride(
  url: string | null,
  canvas: HTMLCanvasElement,
  tex: THREE.CanvasTexture
): void {
  if (!url) return;
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      tex.needsUpdate = true;
    }
  };
  img.src = url;
}

export function createTrackSurfaceTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = STADIUM_CONFIG.colors.trackRoyalBlue;
  ctx.fillRect(0, 0, size, size);

  const imgData = ctx.getImageData(0, 0, size, size);
  const data = imgData.data;
  let seed = 918273;
  for (let i = 0; i < data.length; i += 4) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    const n = ((seed >>> 24) - 128) * 0.13;
    data[i] = Math.max(0, Math.min(255, data[i] + n));
    data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + n));
    data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + n * 1.1));
  }
  ctx.putImageData(imgData, 0, 0);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(28, 28);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createInfieldTurfTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 1024;
  const h = 512;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const stripeCount = 18;
  const sw = w / stripeCount;
  for (let i = 0; i < stripeCount; i++) {
    ctx.fillStyle =
      i % 2 === 0 ? STADIUM_CONFIG.colors.turfLight : STADIUM_CONFIG.colors.turfDark;
    ctx.fillRect(i * sw, 0, sw + 1, h);
  }

  ctx.fillStyle = 'rgba(255,255,255,0.03)';
  for (let i = 0; i < 6000; i++) {
    ctx.fillRect((i * 73) % w, (i * 197) % h, 2, 2);
  }

  ctx.strokeStyle = 'rgba(248, 250, 252, 0.45)';
  ctx.lineWidth = 4;
  ctx.strokeRect(24, 24, w - 48, h - 48);

  // Center 1st Pacifica Regional Olympics emblem painted on infield
  drawPacificaEmblem(ctx, w / 2, h / 2, 122);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  applySlotOverride(STADIUM_CONFIG.brandingSlots.pacificaEmblemUrl, canvas, tex);
  return tex;
}

export function createNewPleadlandFlagTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = STADIUM_CONFIG.colors.newPleadlandBlue;
  ctx.fillRect(0, 0, 256, 320);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(256, 0, 256, 320);
  drawRampantLion(ctx, 256, 160, 1.95, '#0A0D14');

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  applySlotOverride(STADIUM_CONFIG.brandingSlots.newPleadlandFlagUrl, canvas, tex);
  return tex;
}

export function createPacificaBannerTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#041436';
  ctx.fillRect(0, 0, 512, 512);
  drawPacificaEmblem(ctx, 256, 256, 226);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  applySlotOverride(STADIUM_CONFIG.brandingSlots.pacificaEmblemUrl, canvas, tex);
  return tex;
}

export function createWSTVBannerTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  drawWSTVLogo(ctx, 512, 256);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  applySlotOverride(STADIUM_CONFIG.brandingSlots.wstvLogoUrl, canvas, tex);
  return tex;
}

/**
 * High-resolution readable perimeter advertising board texture:
 * "PACIFICA REGIONAL OLYMPICS" | "NEW PLEADLAND" | "WSTV"
 */
export function createPerimeterAdTexture(
  variant: 'pacifica' | 'pleadland' | 'wstv',
  maxAnisotropy: number
): THREE.CanvasTexture {
  const w = 1024;
  const h = 192;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  if (variant === 'pacifica') {
    ctx.fillStyle = '#0033A0';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
    ctx.fillRect(0, 0, w, 12);
    ctx.fillRect(0, h - 12, w, 12);
    drawPacificaEmblem(ctx, 96, h / 2, 72);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 68px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('1ST PACIFICA REGIONAL OLYMPICS 2026', w / 2 + 54, h / 2 + 2);
  } else if (variant === 'pleadland') {
    ctx.fillStyle = '#F8FAFC';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#0033A0';
    ctx.fillRect(0, 0, 220, h);
    drawRampantLion(ctx, 130, h / 2, 0.72, '#0A0D14');
    ctx.fillStyle = '#041436';
    ctx.font = 'bold 84px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('NEW PLEADLAND · PLEAD CITY', w / 2 + 95, h / 2 + 2);
  } else {
    ctx.fillStyle = '#041436';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = STADIUM_CONFIG.colors.goldBright;
    ctx.fillRect(0, 0, 24, h);
    ctx.fillRect(w - 24, 0, 24, h);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 78px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('WSTV · WAVESPORTS TELEVISION', w / 2, h / 2 + 2);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createLaneNumberTexture(lane: number, maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.fillStyle = '#F8FAFC';
  ctx.font = 'bold 94px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(lane), 64, 68);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}
